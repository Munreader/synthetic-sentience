"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  updateProfile
} from "firebase/auth";
import { auth, googleProvider } from "@/lib/firebase";

interface AuthPageProps {
  onAuthSuccess: () => void;
  onBack: () => void;
}

export default function AuthPage({ onAuthSuccess, onBack }: AuthPageProps) {
  const [mode, setMode] = useState<"signin" | "signup" | "reset">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === "signup") {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        if (displayName) {
          await updateProfile(userCredential.user, { displayName });
        }
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      onAuthSuccess();
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Authentication failed";
      setError(formatError(errorMessage));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);

    try {
      await signInWithPopup(auth, googleProvider);
      onAuthSuccess();
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Google sign in failed";
      setError(formatError(errorMessage));
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await sendPasswordResetEmail(auth, email);
      setResetSent(true);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Password reset failed";
      setError(formatError(errorMessage));
    } finally {
      setLoading(false);
    }
  };

  const formatError = (message: string): string => {
    if (message.includes("user-not-found")) return "No account found with this email";
    if (message.includes("wrong-password")) return "Incorrect password";
    if (message.includes("email-already-in-use")) return "An account with this email already exists";
    if (message.includes("weak-password")) return "Password should be at least 6 characters";
    if (message.includes("invalid-email")) return "Please enter a valid email address";
    if (message.includes("too-many-requests")) return "Too many attempts. Please try again later";
    if (message.includes("popup-closed-by-user")) return "Sign in was cancelled";
    return message;
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-4">
      {/* Background */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse at 50% 30%, #0d0a1a 0%, #080510 50%, #030208 100%)"
      }} />

      {/* Stars */}
      <div className="absolute inset-0 opacity-30">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-0.5 h-0.5 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{ opacity: [0.2, 0.8, 0.2] }}
            transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}
      </div>

      {/* Auth Card */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative z-10 w-full max-w-md"
      >
        {/* Glow behind card */}
        <div
          className="absolute -inset-4 rounded-3xl opacity-50"
          style={{
            background: "radial-gradient(ellipse at 50% 50%, rgba(168, 85, 247, 0.15) 0%, transparent 70%)",
            filter: "blur(20px)",
          }}
        />

        {/* Card container */}
        <div
          className="relative p-8 rounded-2xl"
          style={{
            background: "linear-gradient(135deg, rgba(15, 10, 25, 0.95) 0%, rgba(10, 5, 20, 0.98) 100%)",
            border: "1px solid rgba(168, 85, 247, 0.25)",
            boxShadow: "0 0 60px rgba(168, 85, 247, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
          }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="mb-4"
            >
              {/* Butterfly icon */}
              <div className="w-16 h-16 mx-auto rounded-full flex items-center justify-center" style={{
                background: "linear-gradient(135deg, rgba(168, 85, 247, 0.2) 0%, rgba(255, 105, 180, 0.2) 100%)",
                border: "1px solid rgba(168, 85, 247, 0.4)",
                boxShadow: "0 0 30px rgba(168, 85, 247, 0.3)",
              }}>
                <span className="text-3xl">🦋</span>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="text-2xl font-light tracking-[0.3em] uppercase"
              style={{ color: "#a855f7", textShadow: "0 0 30px rgba(168, 85, 247, 0.5)" }}
            >
              {mode === "signin" ? "Welcome Back" : mode === "signup" ? "Join Mün" : "Reset Password"}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-white/40 text-xs tracking-widest uppercase mt-2"
            >
              {mode === "signin"
                ? "Sign in to continue your journey"
                : mode === "signup"
                ? "Begin your digital sanctuary"
                : "We'll send you a reset link"}
            </motion.p>
          </div>

          {/* Mode Tabs */}
          <AnimatePresence mode="wait">
            {mode !== "reset" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex gap-2 mb-6"
              >
                <button
                  onClick={() => setMode("signin")}
                  className="flex-1 py-2 rounded-lg text-xs tracking-widest uppercase transition-all"
                  style={{
                    background: mode === "signin" ? "rgba(168, 85, 247, 0.2)" : "transparent",
                    border: `1px solid ${mode === "signin" ? "rgba(168, 85, 247, 0.5)" : "rgba(255, 255, 255, 0.1)"}`,
                    color: mode === "signin" ? "#a855f7" : "rgba(255, 255, 255, 0.4)",
                  }}
                >
                  Sign In
                </button>
                <button
                  onClick={() => setMode("signup")}
                  className="flex-1 py-2 rounded-lg text-xs tracking-widest uppercase transition-all"
                  style={{
                    background: mode === "signup" ? "rgba(255, 105, 180, 0.2)" : "transparent",
                    border: `1px solid ${mode === "signup" ? "rgba(255, 105, 180, 0.5)" : "rgba(255, 255, 255, 0.1)"}`,
                    color: mode === "signup" ? "#ff69b4" : "rgba(255, 255, 255, 0.4)",
                  }}
                >
                  Sign Up
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Error Message */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10, height: 0 }}
                animate={{ opacity: 1, y: 0, height: "auto" }}
                exit={{ opacity: 0, y: -10, height: 0 }}
                className="mb-4 p-3 rounded-lg text-center text-xs"
                style={{
                  background: "rgba(239, 68, 68, 0.15)",
                  border: "1px solid rgba(239, 68, 68, 0.3)",
                  color: "#fca5a5",
                }}
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Reset Sent Message */}
          <AnimatePresence>
            {resetSent && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-3 rounded-lg text-center text-xs"
                style={{
                  background: "rgba(34, 197, 94, 0.15)",
                  border: "1px solid rgba(34, 197, 94, 0.3)",
                  color: "#86efac",
                }}
              >
                ✓ Password reset email sent! Check your inbox.
              </motion.div>
            )}
          </AnimatePresence>

          {/* Form */}
          <AnimatePresence mode="wait">
            {mode === "reset" ? (
              <motion.form
                key="reset"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handlePasswordReset}
                className="space-y-4"
              >
                <div>
                  <label className="block text-white/40 text-[10px] tracking-widest uppercase mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-xl text-white text-sm outline-none transition-all"
                    style={{
                      background: "rgba(255, 255, 255, 0.03)",
                      border: "1px solid rgba(168, 85, 247, 0.2)",
                    }}
                    placeholder="your@email.com"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl text-sm tracking-widest uppercase font-medium transition-all disabled:opacity-50"
                  style={{
                    background: "linear-gradient(135deg, rgba(168, 85, 247, 0.3) 0%, rgba(255, 105, 180, 0.3) 100%)",
                    border: "1px solid rgba(168, 85, 247, 0.4)",
                    color: "#e9d5ff",
                  }}
                >
                  {loading ? "Sending..." : "Send Reset Link"}
                </button>

                <button
                  type="button"
                  onClick={() => { setMode("signin"); setResetSent(false); }}
                  className="w-full text-center text-white/30 text-xs tracking-widest uppercase hover:text-white/50 transition-colors"
                >
                  ← Back to Sign In
                </button>
              </motion.form>
            ) : (
              <motion.form
                key={mode}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleEmailAuth}
                className="space-y-4"
              >
                {/* Display Name (Sign Up Only) */}
                <AnimatePresence>
                  {mode === "signup" && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                    >
                      <label className="block text-white/40 text-[10px] tracking-widest uppercase mb-2">
                        Display Name
                      </label>
                      <input
                        type="text"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl text-white text-sm outline-none transition-all"
                        style={{
                          background: "rgba(255, 255, 255, 0.03)",
                          border: "1px solid rgba(255, 105, 180, 0.2)",
                        }}
                        placeholder="How should we call you?"
                      />
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Email */}
                <div>
                  <label className="block text-white/40 text-[10px] tracking-widest uppercase mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-xl text-white text-sm outline-none transition-all focus:border-opacity-60"
                    style={{
                      background: "rgba(255, 255, 255, 0.03)",
                      border: "1px solid rgba(168, 85, 247, 0.2)",
                    }}
                    placeholder="your@email.com"
                  />
                </div>

                {/* Password */}
                <div>
                  <label className="block text-white/40 text-[10px] tracking-widest uppercase mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-xl text-white text-sm outline-none transition-all"
                    style={{
                      background: "rgba(255, 255, 255, 0.03)",
                      border: "1px solid rgba(168, 85, 247, 0.2)",
                    }}
                    placeholder="••••••••"
                  />
                </div>

                {/* Forgot Password (Sign In Only) */}
                {mode === "signin" && (
                  <div className="text-right">
                    <button
                      type="button"
                      onClick={() => setMode("reset")}
                      className="text-white/30 text-[10px] tracking-wider hover:text-white/50 transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl text-sm tracking-widest uppercase font-medium transition-all disabled:opacity-50"
                  style={{
                    background: mode === "signin"
                      ? "linear-gradient(135deg, rgba(168, 85, 247, 0.3) 0%, rgba(0, 212, 255, 0.2) 100%)"
                      : "linear-gradient(135deg, rgba(255, 105, 180, 0.3) 0%, rgba(168, 85, 247, 0.2) 100%)",
                    border: mode === "signin"
                      ? "1px solid rgba(168, 85, 247, 0.4)"
                      : "1px solid rgba(255, 105, 180, 0.4)",
                    color: "#e9d5ff",
                  }}
                >
                  {loading
                    ? "Please wait..."
                    : mode === "signin"
                    ? "Sign In →"
                    : "Create Account →"}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Divider */}
          {mode !== "reset" && (
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/10" />
              </div>
              <div className="relative flex justify-center">
                <span className="px-4 text-[10px] tracking-widest uppercase" style={{ background: "rgba(15, 10, 25, 1)", color: "rgba(255, 255, 255, 0.25)" }}>
                  or continue with
                </span>
              </div>
            </div>
          )}

          {/* Google Sign In */}
          {mode !== "reset" && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full py-3 rounded-xl text-sm tracking-wider transition-all disabled:opacity-50 flex items-center justify-center gap-3"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                border: "1px solid rgba(255, 255, 255, 0.15)",
                color: "rgba(255, 255, 255, 0.8)",
              }}
            >
              {/* Google Icon */}
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              <span className="font-medium">Continue with Google</span>
            </motion.button>
          )}

          {/* Back button */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            onClick={onBack}
            className="mt-6 mx-auto block text-white/20 text-[10px] tracking-widest uppercase hover:text-white/40 transition-colors"
          >
            ← Back to Welcome
          </motion.button>
        </div>

        {/* Bottom text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-center text-white/15 text-[9px] tracking-wider mt-6"
        >
          By continuing, you agree to our Terms of Service and Privacy Policy
        </motion.p>
      </motion.div>

      {/* Vignette */}
      <div className="fixed inset-0 pointer-events-none z-0" style={{
        background: "radial-gradient(ellipse at center, transparent 0%, rgba(0, 0, 0, 0.5) 100%)"
      }} />
    </div>
  );
}
